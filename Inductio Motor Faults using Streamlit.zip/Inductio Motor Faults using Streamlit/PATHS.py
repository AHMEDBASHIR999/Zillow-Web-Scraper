# NAVBAR_PATHS = {
#     'HOME':'home',
#     'PLOTS': 'plot',
#     'FFT': 'FFT',
#     'KNN':'KNN',
#     'SVM': 'SVM',
#     'LOGISTIC REGRESSION': 'LOGISTIC REGRESSION'
# }

# # SETTINGS = {
# #     'OPTIONS':'options',
# #     'CONFIGURATION':'configuration'
# # }